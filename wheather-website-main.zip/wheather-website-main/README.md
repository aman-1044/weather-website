# :woman_technologist: wheather-website 

*simple wheather-website using CSS, HTML and JAVASCRIPT.*

#  :calling: website screenshots

![IMG_20220628_112832](https://user-images.githubusercontent.com/92304590/176106976-9655bd8c-bf6d-480b-aec5-a6d6b9df9d37.jpg) 


![IMG_20220628_001739](https://user-images.githubusercontent.com/92304590/176108559-dffa5968-89b0-4abd-818c-2220227f1b55.jpg) 
